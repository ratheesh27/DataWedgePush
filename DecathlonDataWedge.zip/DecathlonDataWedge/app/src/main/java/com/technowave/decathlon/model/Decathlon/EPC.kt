package com.technowave.decathlon.model.Decathlon

data class EPC(
    val epc: String
)