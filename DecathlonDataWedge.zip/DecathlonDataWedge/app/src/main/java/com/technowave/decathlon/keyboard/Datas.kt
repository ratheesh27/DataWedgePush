package com.technowave.decathlon.keyboard

object Datas {
    var DATA=""
}