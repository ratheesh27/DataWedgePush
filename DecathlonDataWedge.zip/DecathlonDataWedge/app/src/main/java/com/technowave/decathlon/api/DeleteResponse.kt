package com.technowave.decathlon.api

data class DeleteResponse(
    val Msg: String,
    val Result: Boolean
)