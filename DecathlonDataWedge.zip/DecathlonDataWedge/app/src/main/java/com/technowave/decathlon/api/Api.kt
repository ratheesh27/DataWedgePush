package com.technowave.decathlon.api


interface Api {

}

