package com.technowave.decathlon.fragment

interface EpcListener {
    fun sendEpc(epc:String)
}