package com.technowave.decathlon.api

data class UpInfo(
    val RFID: String
)