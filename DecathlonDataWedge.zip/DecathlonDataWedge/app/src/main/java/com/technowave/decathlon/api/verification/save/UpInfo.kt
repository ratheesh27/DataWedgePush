package com.technowave.decathlon.api.verification.save

data class UpInfo(
    val RFID: String
)