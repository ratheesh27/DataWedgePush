package com.technowave.decathlon.repository

data class StoreCodeRequest(
    val storecode: String
)

