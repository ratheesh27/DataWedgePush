package com.technowave.decathlon.adapter

data class HomeMenu(var id: Int,var name:String,var icon:Int)
