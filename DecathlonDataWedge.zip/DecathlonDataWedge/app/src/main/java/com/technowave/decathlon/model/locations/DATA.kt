package com.technowave.decathlon.model.locations

data class DATA(
    val LOCATION_CODE: String
)