package com.technowave.decathlon.model.locations

data class DataSet(
    val DATA: List<DATA>
)